@extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '400')
@section('message', __('Bad Request'))