@extends('template.layout')

@section('title', 'Peminjaman - ' . ($level == 'admin' ? 'Admin' : '') . ' Perpustakaan')


@section('main')
    @if ($level === 'admin')
        <div class="container my-5">
            <h1>Data Peminjaman Buku</h1>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view" type="button"
                        role="tab" aria-controls="view" aria-selected="true">Lihat Data Peminjaman</button>
                </li>
            </ul>

            <div class="tab-content" id="myTabContent">
                <!-- Lihat Data Peminjaman -->
                <div class="tab-pane fade show active" id="view" role="tabpanel" aria-labelledby="view-tab">
                    <h2 class="my-3">Lihat Data Peminjaman</h2>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Buku</th>
                                <th>Peminjam</th>
                                <th>Tanggal Peminjaman</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Contoh data peminjaman -->
                            <tr>
                                <td>1</td>
                                <td>Bulan</td>
                                <td>Tere Liye</td>
                                <td>01-08-2024</td>
                                <td>Dipinjam</td>
                                <td>
                                    <a href="#update" class="btn btn-warning btn-sm" data-bs-toggle="tab"
                                        data-bs-target="#update">Update Status</a>
                                    <a href="#denda" class="btn btn-danger" data-bs-toggle="tab"
                                        data-bs-target="#update">Denda</a>
                                </td>
                            </tr>
                            <!-- Tambahkan data lainnya di sini -->
                        </tbody>
                    </table>
                </div>

                <!-- Update Status Peminjaman -->
                <div class="tab-pane fade" id="update" role="tabpanel" aria-labelledby="update-tab">
                    <h2 class="my-3">Update Status Peminjaman</h2>
                    <form>
                        <div class="mb-3">
                            <label for="peminjamanID" class="form-label">ID Peminjaman</label>
                            <input type="text" class="form-control" id="peminjamanID"
                                placeholder="Masukkan ID peminjaman">
                        </div>
                        <div class="mb-3">
                            <label for="statusPeminjaman" class="form-label">Status</label>
                            <select class="form-select" id="statusPeminjaman">
                                <option value="Dipinjam">Dipinjam</option>
                                <option value="Dikembalikan">Dikembalikan</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-warning">Update Status</button>
                    </form>
                </div>
            </div>
        </div>
    @elseif ($level === 'siswa')
        <div class="container-fluid px-4">
            <h1 class="mt-4">Peminjaman Buku</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Halaman Peminjaman Buku</li>
            </ol>
            <form action="">
                <div class="row">
                    <div class="col-12 col-md-4 form-group">
                        <label for="nama" class="form-label">Nama Peminjam *</label>
                        <input type="text" name="nama" id="nama" class="form-control" disabled>
                    </div>
                    <div class="col-12 col-md-4 form-group">
                        <label for="tgl_pinjam" class="form-label">Tanggal Pinjam *</label>
                        <input type="date" name="tgl_pinjam" id="tgl_pinjam" class="form-control">
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-12 col-md-4 form-group">
                        <label for="tgl_kembali" class="form-label">Tanggal Kembali *</label>
                        <input type="date" name="tgl_kembali" id="tgl_kembali" class="form-control">
                    </div>
                    <div class="col-12 col-md-4 form-group">
                        <label for="buku" class="form-label">Buku 1 *</label>
                        <select class="form-control" name="buku" id="buku">
                            <option selected>-Pilih Buku-</option>
                            <option value="bulan">Bulan - Tere Liye</option>
                            <option value="bumi">Bumi - Tere Liye</option>
                        </select>
                    </div>
                </div>
                <div class="row my-3">
                    <div class="col-12 col-md-4 form-group">
                        <button class="btn btn-primary">Buat Peminjaman</button>
                        <button class="btn btn-warning">Tambah Buku</button>
                    </div>
                </div>
            </form>
        </div>
    @endif

@endsection
