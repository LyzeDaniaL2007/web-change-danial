@extends('template.layout')

@section('title', 'Penulis - ' . ($level == 'admin' ? 'Admin' : '') . ' Perpustakaan')

@section('main')

    @if ($level === 'admin')
        <div>
            <div class="container my-5">
                <h1>Penulis Buku</h1>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view"
                            type="button" role="tab" aria-controls="view" aria-selected="true">Lihat Penulis
                            Buku</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="create-tab" data-bs-toggle="tab" data-bs-target="#create"
                            type="button" role="tab" aria-controls="create" aria-selected="false">Tambah Penulis
                            Buku</button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <!-- Lihat Data Kategori Buku -->
                    <div class="tab-pane fade show active" id="view" role="tabpanel" aria-labelledby="view-tab">
                        <h2 class="my-3">Lihat Data Penulis Buku</h2>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Penulis</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data penulis buku -->
                                <tr>
                                    <td>1</td>
                                    <td>Ahmad Danial Adzimmi</td>
                                    <td>
                                        <a href="#update" class="btn btn-warning btn-sm" data-bs-toggle="tab"
                                            data-bs-target="#update">Update</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Cristiano Ronaldo</td>
                                    <td>
                                        <a href="#update" class="btn btn-warning btn-sm" data-bs-toggle="tab"
                                            data-bs-target="#update">Update</a>
                                    </td>
                                </tr>
                                <!-- Tambahkan data lainnya di sini -->
                            </tbody>
                        </table>
                    </div>

                    <!-- Tambah Data Penulis Buku -->
                    <div class="tab-pane fade" id="create" role="tabpanel" aria-labelledby="create-tab">
                        <h2 class="my-3">Tambah Penulis Buku</h2>
                        <form>
                            <div class="mb-3">
                                <label for="kategoriBaru" class="form-label">Nama Penulis Baru</label>
                                <input type="text" class="form-control" id="kategoriBaru"
                                    placeholder="Masukkan nama penulis buku">
                            </div>
                            <button type="submit" class="btn btn-primary">Tambah Penulis buku</button>
                        </form>
                    </div>

                    <!-- Update Data Penulis Buku -->
                    <div class="tab-pane fade" id="update" role="tabpanel" aria-labelledby="update-tab">
                        <h2 class="my-3">Update Penulis Buku</h2>
                        <form>
                            <div class="mb-3">
                                <label for="penulisID" class="form-label">ID Penulis</label>
                                <input type="text" class="form-control" id="penulisID" placeholder="Masukkan ID penulis"
                                    readonly>
                            </div>
                            <div class="mb-3">
                                <label for="penulisNama" class="form-label">Nama Penulis</label>
                                <input type="text" class="form-control" id="penulisNama"
                                    placeholder="Masukkan nama penulis buku yang baru">
                            </div>
                            <button type="submit" class="btn btn-warning">Update </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    @endif

@endsection
