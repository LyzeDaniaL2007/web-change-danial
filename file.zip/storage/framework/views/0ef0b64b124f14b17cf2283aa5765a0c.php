

<?php $__env->startSection('title', 'Halaman Update Kategori'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('template.navbar.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Kategori</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Halaman Update Data Kategori</li>
        </ol>
        <form action="<?php echo e(route('action.updatekategori', ['kategori_id' => $kategori->kategori_id  ])); ?>" class="row my-4 gap-3" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="d-flex flex-row mb-3">
                <div class="col-auto">
                    
                    <label for="inputPassword2" class="visually-hidden">Password</label>
                    <input type="text" name="nama" id="nama" class="form-control"
                        placeholder="Masukkan nama kategori" value="<?php echo e($kategori->kategori_nama); ?>">
                </div>
                <div class="col-auto mx-2">
                    <button class="btn btn-success" type="submit">Update</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\web-change-danial\resources\views/CRUD/kategori/update_kategori.blade.php ENDPATH**/ ?>