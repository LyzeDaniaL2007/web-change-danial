

<?php $__env->startSection('title', 'Halaman Create Kategori'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('template.navbar.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <?php if($level === 'admin'): ?>
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Kategori</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Halaman Create Data Kategori</li>
                </ol>
                <form action="<?php echo e(route('action.createkategori')); ?>" class="row my-4 gap-3" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex flex-row mb-3">
                        <div class="col-auto">
                            
                            <label for="inputPassword2" class="visually-hidden">Password</label>
                            <input type="text" name="nama" id="nama" class="form-control"
                                placeholder="Masukkan nama kategori">
                        </div>
                        <div class="col-auto mx-2">
                            <button class="btn btn-success" type="submit">Tambahkan</button>
                        </div>
                    </div>
                </form>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\web-change-danial\resources\views/CRUD/kategori/create_kategori.blade.php ENDPATH**/ ?>