

<?php $__env->startSection('title', 'Halaman Create Penerbit'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('template.navbar.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<?php if($level === 'admin'): ?>
<div>
    <div class="container">
        <h1>Penerbit Buku</h1>
        <form action="<?php echo e(route('action.createpenerbit')); ?>" class="row my-4 gap-3" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="nama" class="form-label">Nama Penerbit</label>
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Masukkan nama penerbit">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="alamat" class="form-label">Alamat Penerbit</label>
                <input type="text" name="alamat" id="alamat" class="form-control" placeholder="Masukkan alamat penerbit">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="notelp" class="form-label">No Telp Penerbit</label>
                <input type="number" name="notelp" id="notelp" class="form-control" placeholder="Masukkan notelp penerbit">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="email" class="form-label">Email Penerbit</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="Masukkan email penerbit">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <button class="btn btn-success" href="penerbitadmin" type="submit">Tambahkan</button>
            </div>
        </form>
        
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>































<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\web-change-danial\resources\views/general/create_penerbit.blade.php ENDPATH**/ ?>