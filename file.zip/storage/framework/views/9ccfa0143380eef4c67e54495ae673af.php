

<?php $__env->startSection('title', 'Halaman Update Penerbit'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('template.navbar.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Penerbit</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Halaman Update Data Penerbit</li>
        </ol>
        <form action="<?php echo e(route('penerbit.update', ['penerbit_id' => $penerbit->penerbit_id])); ?>" class="row my-4 gap-3"
            method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="nama" class="form-label">Nama Penerbit</label>
                <input type="text" name="nama" id="nama" class="form-control"
                    placeholder="Masukkan nama penerbit" value="<?php echo e($penerbit->penerbit_nama); ?>">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="alamat" class="form-label">Alamat Penerbit</label>
                <input type="text" name="alamat" id="alamat" class="form-control"
                    placeholder="Masukkan alamat penerbit" value="<?php echo e($penerbit->penerbit_alamat); ?>">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="notelp" class="form-label">No Telp Penerbit</label>
                <input type="number" name="notelp" id="notelp" class="form-control" value="<?php echo e($penerbit->penerbit_notelp); ?>"
                    placeholder="Masukkan notelp penerbit">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <label for="email" class="form-label">Email Penerbit</label>
                <input type="email" name="email" id="email" class="form-control"
                    placeholder="Masukkan email penerbit" value="<?php echo e($penerbit->penerbit_email); ?>">
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <button class="btn btn-success" type="submit">Tambahkan</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\web-change-danial\resources\views/general/update_penerbit.blade.php ENDPATH**/ ?>