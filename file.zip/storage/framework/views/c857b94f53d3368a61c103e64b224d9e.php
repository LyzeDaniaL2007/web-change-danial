

<?php $__env->startSection('title', 'Halaman Penerbit'); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('template.navbar.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="container-fluid px-4">
        <h1 class="mt-4">Penerbit</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Halaman Data Penerbit</li>
        </ol>
        <a href="<?php echo e(route('create_penerbit')); ?>">
            <button class="btn btn-primary my-3">Tambah Penerbit</button>
        </a>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(session('updated')): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong>Berhasil!</strong> <?php echo e(session('updated')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(session('deleted')): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong>Berhasil!</strong> <?php echo e(session('deleted')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="row">No</th>
                        <th scope="row">Nama Penerbit</th>
                        <th scope="row">Alamat Penerbit</th>
                        <th scope="row">No Telp Penerbit</th>
                        <th scope="row">Email Penerbit</th>
                        <th scope="row">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $penerbit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penerbit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($penerbit->penerbit_nama); ?></td>
                            <td><?php echo e($penerbit->penerbit_alamat); ?></td>
                            <td><?php echo e($penerbit->penerbit_notelp); ?></td>
                            <td><?php echo e($penerbit->penerbit_email); ?></td>
                            <td>
                                <div class="d-flex flex-row">
                                    <a href="<?php echo e(route('update_penerbit', ['penerbit_id' => $penerbit->penerbit_id])); ?>">
                                        <button class="btn btn-warning"><i class="fas fa-pencil"></i></button>
                                    </a>
                                    <form
                                        action="<?php echo e(route('penerbit.delete', ['penerbit_id' => $penerbit->penerbit_id])); ?>"
                                        method="POST" class="mx-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\web-change-danial\resources\views/general/penerbit.blade.php ENDPATH**/ ?>