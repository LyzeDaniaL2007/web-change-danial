

<?php $__env->startSection('title', 'Buku - ' . ($level == 'admin' ? 'Admin' : '') . ' Perpustakaan'); ?>

<?php $__env->startSection('main'); ?>

<?php if($level === 'admin'): ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Buku</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Halaman Data Buku</li>
    </ol>
    <button class="btn btn-primary mb-3">Tambah Buku</button>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul Buku</th>
                    <th>Penulis Buku</th>
                    <th>Penerbit Buku</th>
                    <th>Tahun Terbit</th>
                    <th>Kategori Buku</th>
                    <th>Rak Buku</th>
                    <th>ISBN</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Bulan</td>
                    <td>Tere Liye</td>
                    <td>Gramedia</td>
                    <td>2018</td>
                    <td>Fiksi</td>
                    <td>L-4</td>
                    <td>12345464564564</td>
                    <td>
                        <button class="btn btn-warning">Update</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php elseif($level === 'siswa'): ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Buku</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Halaman Daftar Buku</li>
    </ol>
    <div class="row gap-4">
        <div class="card col-12 col-md-4 col-lg-3">
            <div class="card-body">
                <img src="./img/bulan.jpg" alt="Bulan" class="book-img">
                <hr>
                <p class="text-center fw-bolder fs-4 my-0">Bulan</p>
                <p class="text-center mb-3">Ditulis oleh Tere Liye</p>
                <button class="btn btn-primary d-block mx-auto" type="submit">Pinjam</button>
            </div>
        </div>
        <div class="card col-12 col-md-4 col-lg-3">
            <div class="card-body">
                <img src="./img/bulan.jpg" alt="Bulan" class="book-img">
                <hr>
                <p class="text-center fw-bolder fs-4 my-0">Bulan</p>
                <p class="text-center mb-3">Ditulis oleh Tere Liye</p>
                <button class="btn btn-primary d-block mx-auto" type="submit">Pinjam</button>
            </div>
        </div>
        <div class="card col-12 col-md-4 col-lg-3">
            <div class="card-body">
                <img src="./img/bulan.jpg" alt="Bulan" class="book-img">
                <hr>
                <p class="text-center fw-bolder fs-4 my-0">Bulan</p>
                <p class="text-center mb-3">Ditulis oleh Tere Liye</p>
                <button class="btn btn-primary d-block mx-auto" type="submit">Pinjam</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\web-change-danial\resources\views/general/buku.blade.php ENDPATH**/ ?>