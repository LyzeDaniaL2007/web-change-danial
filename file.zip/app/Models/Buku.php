<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Buku extends Model
{
    protected $table = 'buku';
    protected $primaryKey = 'buku_id';
    public $incrementing = false;
    public $timestamps = false;
    protected $fillable = [
        'buku_id',
        'buku_judulbuku',
        'buku_penulisbuku',
        'buku_penerbitbuku',
        'buku_tahunterbit',
        'buku_kategoribuku',
        'buku_rakbuku',
        'buku_isbn',
    ];

    protected static function createBuku ($data)
    {
        return self::create($data);
    }
}
