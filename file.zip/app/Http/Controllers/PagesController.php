<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;
use App\Models\Penerbit;

class PagesController extends Controller
{
  public function loginPage()
  {
    return view('public.login');
  }

  public function dashboardadmin()
  {
    return view('general.dashboard', ['level' => 'admin']);
  }

  public function dashboardsiswa()
  {
    return view('general.dashboard', ['level' => 'siswa']);
  }

  public function bukuadmin()
  {
    return view('general.buku', ['level' => 'admin']);
  }

  public function bukusiswa()
  {
    return view('general.buku', ['level' => 'siswa']);
  }

  public function peminjamanadmin()
  {
    return view('general.peminjaman', ['level' => 'admin']);
  }
  public function peminjamansiswa()
  {
    return view('general.peminjaman', ['level' => 'siswa']);
  }

  public function pengaturanadmin()
  {
    return view('general.pengaturan', ['level' => 'admin']);
  }
  public function pengaturansiswa()
  {
    return view('general.pengaturan', ['level' => 'siswa']);
  }

  public function penulisadmin()
  {
    return view('general.penulis', ['level' => 'admin']);
  }

  public function kategoriadmin()
  {
    $data = Kategori::all();

    // return $data;

    return view('general.kategori', [
      'level' => 'admin',
      'kategori' => $data,
    ]);
  
  }

  public function create_buku()
  {
    return view('CRUD.buku.create_buku');
  }

  public function create_kategori()
  {
    return view('CRUD.kategori.create_kategori', ['level' => 'admin']);
  }
  
  public function penerbitadmin() {
    $data = Penerbit::readPenerbit();

    return view('general.penerbit', ['level' => 'admin'])->with('penerbit', $data);
}

  public function create_penerbit()
  {
    return view('CRUD.penerbit.create_penerbit', ['level' => 'admin']);
  }

  public function update_penerbit($id)
  {
    $data = Penerbit::where('penerbit_id', $id)->first();

    return view('CRUD.penerbit.update_penerbit', [
      "penerbit" => $data,
      "level" => "admin",
    ]);
  }

  public function update_kategori($id)
  {
    $data = Kategori::where('kategori_id', $id)->first();

    return view('CRUD.kategori.update_kategori', [
      "kategori" => $data,
      "level" => "admin",
    ]);
  }

  public function kategori() {
    $data = Penerbit::readKategori();

    return view('pages.kategori', ['level' => 'admin'])->with('kategori', $data);
}
}
