<?php

namespace App\Http\Controllers;

use App\Http\Requests\BookRequest;
use App\Http\Requests\StoreBookRequest;
use App\Models\Buku;
use Illuminate\Http\Request;

class BukuController extends Controller
{
    public function index()
    {
        return view('views.buku', ['level' => 'siswa']);
    }

    public function indexAdmin()
    {
        return view('views.buku', ['level' => 'admin']);
    }

    public function store (StoreBookRequest $request)
    {
        $validated = $request->validated();

        $databuku  =[
            'kode_buku' => $validated['kode_buku'],
            'nama_buku' => $validated['nama_buku'],
            'penerbit_buku' => $validated['penerbit_buku'],
            'tahun_terbit' => $validated['tahun_terbit'],
            'penulis_buku' => $validated['penulis_buku']
        ];

      if($databuku){
        dd($databuku);
      } else {
        return back()->WithErrors($validated)->WithInput();
      }
    }

    public function create (Request $request)
{
    $id = mt_rand(1000000000000000, 9999999999999999);

    $data = [
       'penerbit_id' => $id,
        'penerbit_judulbuku' => $request->input('judulbuku'), 
        'penerbit_penulisbuku' => $request->input('penulisbuku'),
        'penerbit_penerbitbuku' => $request->input('penerbitbuku'),
        'penerbit_tahunterbit' => $request->input('tahunterbit'),
        'penerbit_kategoribuku' => $request->input('kategoribuku'),
        'penerbit_rakbuku' => $request->input('rakbuku'),
        'penerbit_isbn' => $request->input('isbn'),
    ];

    Buku::createBuku($data);

    return redirect()->route('bukuadmin')->with('success', 'Data Buku berhasil ditambahkan!');
}
}
